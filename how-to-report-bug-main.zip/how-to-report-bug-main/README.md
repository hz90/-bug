# how-to-report-bug

Important Features in Your Bug Report
#1) Bug Number/id 号
#2) Bug Title   标题
#3) Priority   优先级
#4) Platform/Environment  发生环境
#5) Description 客观描述bug
#6) Steps to Reproduce  如何重现的  一步一步
#7) Expected and Actual Result   预期的是什么实际的是什么
#8) Screenshot 截图
